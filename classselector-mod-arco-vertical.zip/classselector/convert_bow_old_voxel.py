#!/usr/bin/env python3
"""Converte modelsrc/hyper_arco_sculk.obj (modelo voxel do usuário) em modelos JSON de item do Minecraft 1.20.1.

- Cada face do OBJ vira um plano (elemento de espessura zero) com o UV original (retalho 14x14 do atlas 128x128).
  Planos vizinhos, coplanares, de mesmo sentido e mesma região de textura são fundidos (menos elementos).
- A corda do OBJ (coluna fina) é removida e refeita como cubos, para poder recuar quando o arco é puxado.
- Orientação: o OBJ tem o arco ao longo de Y, corda em +X. Giramos 180° em Y (sem espelhar) e inclinamos 45° em Z
  (convenção diagonal do arco vanilla, para o display vanilla funcionar).
Uso: python3 convert_bow.py
"""
import json, os, collections

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "modelsrc")
RES = os.path.join(ROOT, "src/main/resources/assets/classselector")
NAME = "hyper_sculk_bow"
G = 0.025                       # tamanho do voxel no OBJ (blocos)
CX, CY, CZ = -0.05, -0.07, 0.06  # ponto do OBJ que vai para o centro (8,8,8) do modelo (empunhadura/núcleo)
PX = 16.0                        # 1 bloco = 16 px

V, VT, F = [], [], []
for l in open(os.path.join(SRC, "hyper_arco_sculk.obj")):
    p = l.split()
    if not p: continue
    if p[0] == "v": V.append(tuple(map(float, p[1:4])))
    elif p[0] == "vt": VT.append(tuple(map(float, p[1:3])))
    elif p[0] == "f": F.append([tuple(int(i) for i in t.split("/")) for t in p[1:]])

def gi(c): return int(round(c / G))

# --- faces do OBJ -> (eixo, plano, sinal, tile, célula) em grade inteira ---
def face_info(f):
    pts = [V[t[0] - 1] for t in f]
    axis = [a for a in range(3) if len({gi(p[a]) for p in pts}) == 1][0]
    a, b, c = pts[0], pts[1], pts[2]
    u = [b[i] - a[i] for i in range(3)]; w = [c[i] - a[i] for i in range(3)]
    n = [u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]]
    sign = 1 if n[axis] > 0 else -1
    others = [i for i in range(3) if i != axis]
    cell = tuple(min(gi(p[o]) for p in pts) for o in others)
    us = [VT[t[1] - 1][0] for t in f]
    tile = int(round(min(us) * 128)) // 16
    return axis, gi(pts[0][axis]), sign, tile, cell, pts

# coluna da corda no OBJ
SX = (gi(0.125), gi(0.15)); SZ = (gi(0.05), gi(0.075))
groups = collections.defaultdict(set)
string_y = []
for f in F:
    axis, plane, sign, tile, cell, pts = face_info(f)
    xs = [gi(p[0]) for p in pts]; zs = [gi(p[2]) for p in pts]
    if min(xs) >= SX[0] and max(xs) <= SX[1] and min(zs) >= SZ[0] and max(zs) <= SZ[1]:
        string_y += [gi(p[1]) for p in pts]
        continue                                  # corda: refeita abaixo
    groups[(axis, plane, sign, tile)].add(cell)
Y0, Y1 = min(string_y), max(string_y)            # extensão da corda (grade)

def merge(cells):
    cells = set(cells); out = []
    for (i, j) in sorted(cells):
        if (i, j) not in cells: continue
        j2 = j
        while (i, j2 + 1) in cells: j2 += 1
        i2 = i
        while all((i2 + 1, jj) in cells for jj in range(j, j2 + 1)): i2 += 1
        for ii in range(i, i2 + 1):
            for jj in range(j, j2 + 1): cells.discard((ii, jj))
        out.append((i, j, i2 + 1, j2 + 1))
    return out

def loc(x, y, z):   # coordenadas do OBJ (blocos) -> locais em px (giro de 180° em Y, centrado)
    return (8 - (x - CX) * PX, 8 + (y - CY) * PX, 8 - (z - CZ) * PX)

DIRS = {(0, 1): "east", (0, -1): "west", (1, 1): "up", (1, -1): "down", (2, 1): "south", (2, -1): "north"}
ROT = {"angle": 45, "axis": "z", "origin": [8, 8, 8]}
def uvrect(t): return [t * 16 + 1, 1, t * 16 + 15, 15]

def r4(v): return round(v, 4)
body = []
for (axis, plane, sign, tile), cells in sorted(groups.items()):
    others = [i for i in range(3) if i != axis]
    for (i0, j0, i1, j1) in merge(cells):
        lo = [0.0] * 3; hi = [0.0] * 3
        lo[axis] = hi[axis] = plane * G
        lo[others[0]], hi[others[0]] = i0 * G, i1 * G
        lo[others[1]], hi[others[1]] = j0 * G, j1 * G
        a = loc(*lo); b = loc(*hi)
        frm = [r4(min(a[k], b[k])) for k in range(3)]
        to = [r4(max(a[k], b[k])) for k in range(3)]
        lsign = sign if axis == 1 else -sign       # x e z foram invertidos
        body.append({"from": frm, "to": to, "rotation": ROT,
                     "faces": {DIRS[(axis, lsign)]: {"uv": uvrect(tile), "texture": "#0"}}})

def cube(a, b, tile):
    faces = {d: {"uv": uvrect(tile), "texture": "#0"} for d in ("north", "east", "south", "west", "up", "down")}
    return {"from": [r4(v) for v in a], "to": [r4(v) for v in b], "rotation": ROT, "faces": faces}

def string(shift_vox, halo):
    """Corda: coluna de 1 voxel que recua no meio (formato de V em degraus de 0,4 px)."""
    els = []
    n = Y1 - Y0
    mid = (Y0 + Y1) / 2.0; half = (Y1 - Y0) / 2.0
    shifts = []
    for k in range(n):
        w = 1.0 - abs((Y0 + k + 0.5) - mid) / half
        shifts.append(int(round(shift_vox * w)))
    k = 0
    while k < n:
        k2 = k
        while k2 + 1 < n and shifts[k2 + 1] == shifts[k]: k2 += 1
        a = loc(SX[1] * G, (Y0 + k) * G, SZ[1] * G)
        b = loc(SX[0] * G, (Y0 + k2 + 1) * G, SZ[0] * G)
        off = shifts[k] * G * PX
        els.append(cube([min(a[0], b[0]) - off, min(a[1], b[1]), min(a[2], b[2])],
                        [max(a[0], b[0]) - off, max(a[1], b[1]), max(a[2], b[2])], 6))
        k = k2 + 1
    if halo:   # carga máxima: halo luminoso em volta do núcleo
        cx, cy, cz = loc(-0.10, -0.05, 0.05)
        for dx, dy in [(3, 0), (-3, 0), (0, 3), (0, -3), (2.1, 2.1), (-2.1, 2.1), (2.1, -2.1), (-2.1, -2.1)]:
            els.append(cube([cx + dx - .6, cy + dy - .6, cz - .6], [cx + dx + .6, cy + dy + .6, cz + .6], 6))
    return els

# Vanilla bow display; escala ajustada p/ o arco ter ~1,6 bloco na mão (OBJ tem 1,45 bloco de comprimento).
S3, S1, SG = 1.1, 0.8, 0.9
DISPLAY = {
    "thirdperson_righthand": {"rotation": [-80, 260, -40], "translation": [-1, -2, 2.5], "scale": [S3] * 3},
    "thirdperson_lefthand":  {"rotation": [-80, -280, 40], "translation": [-1, -2, 2.5], "scale": [S3] * 3},
    "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [S1] * 3},
    "firstperson_lefthand":  {"rotation": [0, 90, -25], "translation": [1.13, 3.2, 1.13], "scale": [S1] * 3},
    "gui":    {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [SG] * 3},
    "fixed":  {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [SG] * 3},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.7] * 3},
}

def model(shift, halo=False, overrides=None):
    els = body + string(shift, halo)
    for e in els:
        assert all(-16 <= v <= 32 for v in e["from"] + e["to"]), e
    m = {"texture_size": [128, 128],
         "textures": {"0": f"classselector:item/{NAME}", "particle": f"classselector:item/{NAME}"},
         "elements": els, "display": DISPLAY}
    if overrides: m["overrides"] = overrides
    return m

d = os.path.join(RES, "models/item"); os.makedirs(d, exist_ok=True)
def save(name, m):
    with open(os.path.join(d, name + ".json"), "w", encoding="utf-8") as f:
        json.dump(m, f, separators=(",", ":"))

ov = [
    {"predicate": {"pulling": 1}, "model": f"classselector:item/{NAME}_pulling_0"},
    {"predicate": {"pulling": 1, "pull": 0.4}, "model": f"classselector:item/{NAME}_pulling_1"},
    {"predicate": {"pulling": 1, "pull": 0.8}, "model": f"classselector:item/{NAME}_pulling_2"},
    {"predicate": {"pulling": 1, "pull": 1.0}, "model": f"classselector:item/{NAME}_pulling_3"},
]
save(NAME, model(0, overrides=ov))
save(f"{NAME}_pulling_0", model(3))
save(f"{NAME}_pulling_1", model(6))
save(f"{NAME}_pulling_2", model(9))
save(f"{NAME}_pulling_3", model(11, halo=True))

# textura do usuário, sem alterações
from shutil import copyfile
os.makedirs(os.path.join(RES, "textures/item"), exist_ok=True)
copyfile(os.path.join(SRC, "hyper_arco_sculk_texture.png"), os.path.join(RES, f"textures/item/{NAME}.png"))
print("faces OBJ:", len(F), "-> elementos do corpo:", len(body), "| corda: voxels", Y1 - Y0)
