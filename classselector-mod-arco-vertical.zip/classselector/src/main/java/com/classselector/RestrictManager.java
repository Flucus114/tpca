package com.classselector;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;

public class RestrictManager {
    public static String classOf(Player p) {
        return p.getPersistentData().getString(ClassSelectorMod.KEY);
    }

    /** Regras da classe do jogador (só no servidor). */
    public static Set<String> rulesOf(ServerPlayer p) {
        String cls = classOf(p);
        if (cls.isEmpty()) return Collections.emptySet();
        Set<String> s = RestrictionData.get(p.server).blocked.get(cls);
        return s == null ? Collections.emptySet() : s;
    }

    /** Vale nos dois lados: no cliente usa as regras sincronizadas. */
    public static boolean isBlocked(Player p, ItemStack s) {
        if (s.isEmpty()) return false;
        if (p.level().isClientSide) return RestrictClientState.isBlocked(s);
        if (!(p instanceof ServerPlayer sp)) return false;
        return RestrictionData.matches(rulesOf(sp), s);
    }

    public static void sync(ServerPlayer p) {
        RestrictNet.send(p, new ArrayList<>(rulesOf(p)));
    }

    public static void syncAll(MinecraftServer s) {
        for (ServerPlayer p : s.getPlayerList().getPlayers()) sync(p);
    }
}
