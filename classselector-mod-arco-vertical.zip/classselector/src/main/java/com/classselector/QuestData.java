package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.LinkedHashMap;
import java.util.Map;

/** Abas e quests definidas pelos OPs (salvas no mundo). */
public class QuestData extends SavedData {
    public final Map<String, QuestTabDef> tabs = new LinkedHashMap<>();
    public final Map<String, QuestDef> quests = new LinkedHashMap<>();

    public static QuestData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(QuestData::load, QuestData::createDefault, "classselector_quests");
    }

    private static QuestTabDef tab(String id, String name, String icon) {
        QuestTabDef t = new QuestTabDef();
        t.id = id; t.name = name; t.icon = icon;
        return t;
    }

    private static QuestDef quest(String id, String tab, String parent, String name, String desc, String icon,
                                  QuestType type, String target, int amount, int xp, ItemStack... rewards) {
        QuestDef q = new QuestDef();
        q.id = id; q.tab = tab; q.parent = parent; q.name = name; q.description = desc; q.icon = icon;
        q.type = type; q.target = target; q.amount = amount; q.xp = xp;
        for (ItemStack s : rewards) q.rewards.add(s);
        return q;
    }

    private static QuestData createDefault() {
        QuestData d = new QuestData();
        QuestTabDef t1 = tab("inicio", "Início", "minecraft:oak_sapling");
        QuestTabDef t2 = tab("chefes", "Chefes", "minecraft:wither_skeleton_skull");
        d.tabs.put(t1.id, t1);
        d.tabs.put(t2.id, t2);

        QuestDef[] qs = {
            quest("madeira", "inicio", "", "Primeiros passos", "Colete troncos de carvalho.",
                    "minecraft:oak_log", QuestType.BLOCK, "minecraft:oak_log", 5, 0, new ItemStack(Items.BREAD, 5)),
            quest("pedra", "inicio", "madeira", "Era da pedra", "Mine pedra.",
                    "minecraft:stone_pickaxe", QuestType.BLOCK, "minecraft:stone", 10, 1, new ItemStack(Items.TORCH, 16)),
            quest("ferro", "inicio", "pedra", "Ferro!", "Tenha barras de ferro no inventário.",
                    "minecraft:iron_ingot", QuestType.ITEM, "minecraft:iron_ingot", 10, 3, new ItemStack(Items.IRON_SWORD)),
            quest("wither", "chefes", "", "Chefe sombrio", "Derrote o Wither.",
                    "minecraft:nether_star", QuestType.BOSS, "minecraft:wither", 1, 10, new ItemStack(Items.DIAMOND, 5)),
            quest("dragao", "chefes", "wither", "Fim do dragão", "Derrote o Ender Dragon.",
                    "minecraft:dragon_head", QuestType.BOSS, "minecraft:ender_dragon", 1, 20, new ItemStack(Items.ELYTRA)),
        };
        for (QuestDef q : qs) d.quests.put(q.id, q);
        d.setDirty();
        return d;
    }

    public static QuestData load(CompoundTag tag) {
        QuestData d = new QuestData();
        for (Tag t : tag.getList("tabs", Tag.TAG_COMPOUND)) {
            QuestTabDef x = QuestTabDef.load((CompoundTag) t);
            if (!x.id.isEmpty()) d.tabs.put(x.id, x);
        }
        for (Tag t : tag.getList("quests", Tag.TAG_COMPOUND)) {
            QuestDef x = QuestDef.load((CompoundTag) t);
            if (!x.id.isEmpty()) d.quests.put(x.id, x);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag tl = new ListTag();
        for (QuestTabDef t : tabs.values()) tl.add(t.save());
        tag.put("tabs", tl);
        ListTag ql = new ListTag();
        for (QuestDef q : quests.values()) ql.add(q.save());
        tag.put("quests", ql);
        return tag;
    }
}
