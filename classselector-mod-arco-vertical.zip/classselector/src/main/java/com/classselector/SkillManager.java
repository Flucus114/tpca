package com.classselector;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashSet;
import java.util.Set;

/** Lógica de servidor da árvore de habilidades. */
public class SkillManager {

    private static void msg(ServerPlayer p, String text, ChatFormatting color) {
        p.sendSystemMessage(Component.literal(text).withStyle(color));
    }

    /** Tenta desbloquear a habilidade, gastando XP e dando os itens configurados. */
    public static void unlock(ServerPlayer p, String id) {
        SkillData sd = SkillData.get(p.server);
        SkillDef s = sd.skills.get(id);
        if (s == null) return;
        QuestTabDef tree = sd.trees.get(s.tree);
        if (tree == null) return;
        if (!p.hasPermissions(2) && !QuestManager.tabAllows(tree, p)) {
            msg(p, "Esta árvore é exclusiva de outra classe.", ChatFormatting.RED);
            return;
        }
        if (!p.hasPermissions(2) && !QuestManager.classAllows(s.classId, p)) {
            msg(p, "Esta habilidade é exclusiva de outra classe.", ChatFormatting.RED);
            return;
        }
        PlayerSkillData pd = PlayerSkillData.get(p.server);
        Set<String> have = pd.of(p.getUUID());
        if (have.contains(s.id)) return;
        if (!s.parent.isEmpty() && sd.skills.containsKey(s.parent) && !have.contains(s.parent)) {
            SkillDef par = sd.skills.get(s.parent);
            msg(p, "Desbloqueie antes: " + par.name, ChatFormatting.RED);
            return;
        }
        boolean free = p.getAbilities().instabuild; // criativo não paga
        if (!free && p.experienceLevel < s.xpCost) {
            msg(p, "Você precisa de " + s.xpCost + " níveis de XP (tem " + p.experienceLevel + ").", ChatFormatting.RED);
            return;
        }

        if (!free && s.xpCost > 0) p.giveExperienceLevels(-s.xpCost);
        have.add(s.id);
        for (ItemStack r : s.rewards) {
            ItemStack c = r.copy();
            if (!p.getInventory().add(c)) p.drop(c, false);
        }
        if (s.xpReward > 0) p.giveExperienceLevels(s.xpReward);
        pd.setDirty();
        msg(p, "Habilidade desbloqueada: " + s.name, ChatFormatting.GREEN);
        p.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1f, 1f);
        sync(p, false);
    }

    public static void sync(ServerPlayer p, boolean open) {
        SkillData sd = SkillData.get(p.server);
        Set<String> have = PlayerSkillData.get(p.server).of(p.getUUID());
        CompoundTag t = new CompoundTag();
        boolean op = p.hasPermissions(2); // OP vê todas as árvores para poder editar

        Set<String> treesSent = new HashSet<>();
        ListTag tl = new ListTag();
        for (QuestTabDef x : sd.trees.values()) {
            if (!op && !QuestManager.tabAllows(x, p)) continue;
            tl.add(x.save());
            treesSent.add(x.id);
        }
        t.put("trees", tl);

        Set<String> skillsSent = new HashSet<>();
        ListTag sl = new ListTag();
        for (SkillDef x : sd.skills.values()) {
            if (!treesSent.contains(x.tree)) continue;
            if (!op && !QuestManager.classAllows(x.classId, p)) continue; // skill de outra classe nem é enviada
            sl.add(x.save());
            skillsSent.add(x.id);
        }
        t.put("skills", sl);

        ListTag ul = new ListTag();
        for (String s : have) if (skillsSent.contains(s)) ul.add(StringTag.valueOf(s));
        t.put("unlocked", ul);
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new SkillNet.SSync(open, t));
    }

    public static void syncAll(MinecraftServer s) {
        for (ServerPlayer p : s.getPlayerList().getPlayers()) sync(p, false);
    }
}
